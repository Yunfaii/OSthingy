#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_REQUESTS 100

void sort_requests(int requests[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (requests[j] > requests[j + 1]) {
                int temp = requests[j];
                requests[j] = requests[j + 1];
                requests[j + 1] = temp;
            }
        }
    }
}

int find_index(int requests[], int n, int head) {
    for (int i = 0; i < n; i++) {
        if (requests[i] > head) {
            return i;
        }
    }
    return n;
}

void c_scan(int head, int requests[], int n, int disk_min, int disk_max, int direction) {
    int total_movement = 0;
    int current_pos = head;
    int step = 1;

    sort_requests(requests, n);
    
    printf("\nAlgoritma: C-SCAN\n");
    printf("Arah: %s\n", (direction == 1) ? "Naik (ke nilai lebih besar)" : "Turun (ke nilai lebih kecil)");
    printf("STEP %d: Head di posisi %d - Movement: 0 - Total movement: %d\n", step++, current_pos, total_movement);
    
    if (direction == 1) { // Naik (upward)
        int index = find_index(requests, n, head);

        // Bergerak ke atas sampai disk_max
        for (int i = index; i < n; i++) {
            int step_movement = abs(current_pos - requests[i]);
            total_movement += step_movement;
            current_pos = requests[i];
            printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
        }

        // Jika belum di disk_max, pindah ke disk_max
        if (current_pos != disk_max) {
            int step_movement = abs(current_pos - disk_max);
            total_movement += step_movement;
            current_pos = disk_max;
            printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
        }

        // Lompat ke disk_min (C-SCAN)
        int step_movement = abs(disk_max - disk_min);
        total_movement += step_movement;
        current_pos = disk_min;
        printf("STEP %d: Head pindah ke %d (lompat ke awal disk) - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);

        // Lanjut bergerak ke atas dari disk_min
        for (int i = 0; i < index; i++) {
            step_movement = abs(current_pos - requests[i]);
            total_movement += step_movement;
            current_pos = requests[i];
            printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
        }
    } 
    else { // Turun (downward)
        int index = find_index(requests, n, head) - 1;

        // Bergerak ke bawah sampai disk_min
        for (int i = index; i >= 0; i--) {
            int step_movement = abs(current_pos - requests[i]);
            total_movement += step_movement;
            current_pos = requests[i];
            printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
        }

        // Jika belum di disk_min, pindah ke disk_min
        if (current_pos != disk_min) {
            int step_movement = abs(current_pos - disk_min);
            total_movement += step_movement;
            current_pos = disk_min;
            printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
        }

        // Lompat ke disk_max (C-SCAN)
        int step_movement = abs(disk_min - disk_max);
        total_movement += step_movement;
        current_pos = disk_max;
        printf("STEP %d: Head pindah ke %d (lompat ke akhir disk) - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);

        // Lanjut bergerak ke bawah dari disk_max
        for (int i = n - 1; i > index; i--) {
            step_movement = abs(current_pos - requests[i]);
            total_movement += step_movement;
            current_pos = requests[i];
            printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
        }
    }
    
    printf("\nTotal pergerakan head: %d\n", total_movement);
}

void c_look(int head, int requests[], int n, int disk_min, int disk_max, int direction) {
    int total_movement = 0;
    int current_pos = head;
    int step = 1;

    sort_requests(requests, n);
    
    printf("\nAlgoritma: C-LOOK\n");
    printf("Arah: %s\n", (direction == 1) ? "Naik (ke nilai lebih besar)" : "Turun (ke nilai lebih kecil)");
    printf("STEP %d: Head di posisi %d - Movement: 0 - Total movement: %d\n", step++, current_pos, total_movement);
    
    if (direction == 1) { // Naik (upward)
        int index = find_index(requests, n, head);

        // Bergerak ke atas sampai request terbesar
        for (int i = index; i < n; i++) {
            int step_movement = abs(current_pos - requests[i]);
            total_movement += step_movement;
            current_pos = requests[i];
            printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
        }

        // Jika ada request di bawah, lompat ke request terkecil (C-LOOK)
        if (index > 0) {
            int step_movement = abs(current_pos - requests[0]);
            total_movement += step_movement;
            current_pos = requests[0];
            printf("STEP %d: Head pindah ke %d (lompat ke request terkecil) - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);

            // Lanjut bergerak ke atas
            for (int i = 0; i < index; i++) {
                step_movement = abs(current_pos - requests[i]);
                total_movement += step_movement;
                current_pos = requests[i];
                printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
            }
        }
    } 
    else { // Turun (downward)
        int index = find_index(requests, n, head) - 1;

        // Bergerak ke bawah sampai request terkecil
        for (int i = index; i >= 0; i--) {
            int step_movement = abs(current_pos - requests[i]);
            total_movement += step_movement;
            current_pos = requests[i];
            printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
        }

        // Jika ada request di atas, lompat ke request terbesar (C-LOOK)
        if (index < n - 1) {
            int step_movement = abs(current_pos - requests[n - 1]);
            total_movement += step_movement;
            current_pos = requests[n - 1];
            printf("STEP %d: Head pindah ke %d (lompat ke request terbesar) - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);

            // Lanjut bergerak ke bawah
            for (int i = n - 1; i > index; i--) {
                step_movement = abs(current_pos - requests[i]);
                total_movement += step_movement;
                current_pos = requests[i];
                printf("STEP %d: Head pindah ke %d - Movement: %d - Total movement: %d\n", step++, current_pos, step_movement, total_movement);
            }
        }
    }
    
    printf("\nTotal pergerakan head: %d\n", total_movement);
}

int main() {
    int head;
    int requests[MAX_REQUESTS];
    int n = 0;
    int disk_min = 0;
    int disk_max = 199;
    int choice_algorithm, choice_direction;
    
    printf("Masukkan posisi awal head: ");
    scanf("%d", &head);
    
    printf("Masukkan jumlah permintaan I/O: ");
    scanf("%d", &n);
    
    printf("Masukkan daftar permintaan (dipisah spasi): ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &requests[i]);
    }
    
    printf("Pilih algoritma yang akan dijalankan\n(1 = C-SCAN, 2 = C-LOOK): ");
    scanf("%d", &choice_algorithm);
    
    printf("Pilih arah pergerakan head\n(1 = Naik, 2 = Turun): ");
    scanf("%d", &choice_direction);
    
    switch (choice_algorithm) {
        case 1:
            c_scan(head, requests, n, disk_min, disk_max, choice_direction);
            break;
        case 2:
            c_look(head, requests, n, disk_min, disk_max, choice_direction);
            break;
        default:
            printf("Pilihan tidak valid.\n");
            return 1;
    }
    
    return 0;
}
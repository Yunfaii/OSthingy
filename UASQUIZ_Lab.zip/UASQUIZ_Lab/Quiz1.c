#include <stdio.h>
#include <stdbool.h>

#define MAX_REFERENCES 50

// Fungsi untuk mengecek apakah page ada di frames
int isInFrames(int frames[], int num_frames, int page) {
    for (int i = 0; i < num_frames; i++) {
        if (frames[i] == page) return i;
    }
    return -1;
}

// Fungsi untuk menghitung page fault dengan LRU
int calculateLRU(int ref[], int n, int num_frames) {
    int frames[num_frames];
    int recent[num_frames];  // Menyimpan waktu terakhir akses
    int time = 0, faults = 0;

    // Inisialisasi frame dan recent
    for (int i = 0; i < num_frames; i++) {
        frames[i] = -1;
        recent[i] = -1;
    }

    for (int i = 0; i < n; i++) {
        int page = ref[i];
        int idx = isInFrames(frames, num_frames, page);

        if (idx != -1) {
            // Page hit, update waktu terakhir dipakai
            recent[idx] = time++;
        } else {
            faults++; // Page fault terjadi
            int empty = -1;

            // Cari frame kosong
            for (int j = 0; j < num_frames; j++) {
                if (frames[j] == -1) {
                    empty = j;
                    break;
                }
            }

            if (empty != -1) {
                // Ada frame kosong, isi dengan page baru
                frames[empty] = page;
                recent[empty] = time++;
            } else {
                // Cari halaman dengan recent terkecil (LRU)
                int lru = 0;
                for (int j = 1; j < num_frames; j++) {
                    if (recent[j] < recent[lru]) {
                        lru = j;
                    }
                }
                // Ganti halaman LRU dengan page baru
                frames[lru] = page;
                recent[lru] = time++;
            }
        }
    }

    return faults;
}

// Fungsi untuk menghitung page fault dengan Optimal
int calculateOptimal(int ref[], int n, int num_frames) {
    int frames[num_frames];
    int faults = 0;

    // Inisialisasi frame
    for (int i = 0; i < num_frames; i++) {
        frames[i] = -1;
    }

    for (int i = 0; i < n; i++) {
        int page = ref[i];
        int idx = isInFrames(frames, num_frames, page);

        if (idx != -1) {
            continue; // Page hit, tidak ada page fault
        }

        faults++; // Page fault terjadi

        int empty = -1;
        // Cari frame kosong
        for (int j = 0; j < num_frames; j++) {
            if (frames[j] == -1) {
                empty = j;
                break;
            }
        }

        if (empty != -1) {
            // Ada frame kosong, isi dengan page baru
            frames[empty] = page;
        } else {
            // Cari halaman yang tidak akan digunakan paling lama
            int farthest = -1, idx_to_replace = -1;

            for (int j = 0; j < num_frames; j++) {
                int next_use = -1;

                // Cari next use dari halaman ini
                for (int k = i + 1; k < n; k++) {
                    if (ref[k] == frames[j]) {
                        next_use = k;
                        break;
                    }
                }

                if (next_use == -1) { 
                    // Halaman ini tidak akan digunakan lagi
                    idx_to_replace = j;
                    break;
                }

                if (next_use > farthest) {
                    farthest = next_use;
                    idx_to_replace = j;
                }
            }

            // Ganti halaman yang dipilih
            frames[idx_to_replace] = page;
        }
    }

    return faults;
}

int main() {
    int num_frames;
    int reference_string[MAX_REFERENCES];
    int num_references = 0;

    printf("Masukkan jumlah frame: ");
    scanf("%d", &num_frames);

    printf("Masukkan page reference string (akhiri dengan -1): ");
    while (1) {
        int page;
        scanf("%d", &page);
        if (page == -1 || num_references >= MAX_REFERENCES) break;
        reference_string[num_references++] = page;
    }

    int lru_faults = calculateLRU(reference_string, num_references, num_frames);
    int optimal_faults = calculateOptimal(reference_string, num_references, num_frames);

    printf("\nJumlah page fault (LRU): %d\n", lru_faults);
    printf("Jumlah page fault (Optimal): %d\n", optimal_faults);

    return 0;
}
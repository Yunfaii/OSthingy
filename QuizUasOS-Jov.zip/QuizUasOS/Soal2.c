#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Tukar dua nilai
void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Urutkan array naik
void sort(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (arr[j] > arr[j + 1])
                swap(&arr[j], &arr[j + 1]);
}

// Fungsi C-LOOK Naik
void clook_naik(int requests[], int n, int head, int disk_size)
{
    int all[n];
    int step = 2, geraktotal = 0, headPrev;

    for (int i = 0; i < n; i++)
        all[i] = requests[i];
    sort(all, n);

    int i;
    for (i = 0; i < n; i++)
    {
        if (all[i] >= head)
            break;
    }

    printf("STEP 1\n");
    printf("Head di track = %d\n", head);
    printf("Pergerakan = 0\n\n");

    // Naik ke atas
    for (int j = i; j < n; j++)
    {
        headPrev = head;
        head = all[j];
        int gerak = abs(head - headPrev);
        printf("STEP %d\n", step++);
        printf("Head di track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
        geraktotal += gerak;
    }

    // Lompat ke request terkecil
    if (i > 0)
    {
        int gerak = abs(head - all[0]);
        head = all[0];
        printf("STEP %d\n", step++);
        printf("Head lompat ke track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
        geraktotal += gerak;

        for (int j = 0; j < i; j++)
        {
            headPrev = head;
            head = all[j];
            gerak = abs(head - headPrev);
            printf("STEP %d\n", step++);
            printf("Head di track = %d\n", head);
            printf("Pergerakan = %d\n\n", gerak);
            geraktotal += gerak;
        }
    }

    printf("Total pergerakan head = %d\n", geraktotal);
}

// Fungsi C-LOOK Turun
void clook_turun(int requests[], int n, int head, int disk_size)
{
    int all[n];
    int step = 2, geraktotal = 0, headPrev;

    for (int i = 0; i < n; i++)
        all[i] = requests[i];
    sort(all, n);

    int i;
    for (i = n - 1; i >= 0; i--)
    {
        if (all[i] <= head)
            break;
    }

    printf("STEP 1\n");
    printf("Head di track = %d\n", head);
    printf("Pergerakan = 0\n\n");

    // Turun ke bawah
    for (int j = i; j >= 0; j--)
    {
        headPrev = head;
        head = all[j];
        int gerak = abs(head - headPrev);
        printf("STEP %d\n", step++);
        printf("Head di track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
        geraktotal += gerak;
    }

    // Lompat ke request terbesar
    if (i < n - 1)
    {
        int gerak = abs(head - all[n - 1]);
        head = all[n - 1];
        printf("STEP %d\n", step++);
        printf("Head lompat ke track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
        geraktotal += gerak;

        for (int j = n - 1; j > i; j--)
        {
            headPrev = head;
            head = all[j];
            gerak = abs(head - headPrev);
            printf("STEP %d\n", step++);
            printf("Head di track = %d\n", head);
            printf("Pergerakan = %d\n\n", gerak);
            geraktotal += gerak;
        }
    }

    printf("Total pergerakan head = %d\n", geraktotal);
}

// Fungsi C-Scan naik
void cscan_naik(int requests[], int n, int head, int disk_size)
{
    int all[n];
    int step = 1;
    int geraktotal = 0;
    int headPrev;

    for (int i = 0; i < n; i++)
        all[i] = requests[i];

    sort(all, n);

    int i;
    for (i = 0; i < n; i++)
    {
        if (all[i] >= head)
            break;
    }

    printf("STEP %d\n", step++);
    printf("Head di track = %d\n", head);
    printf("Pergerakan = 0\n\n");

    // Naik ke atas
    for (int j = i; j < n; j++)
    {
        headPrev = head;
        head = all[j];
        int gerak = abs(head - headPrev);
        geraktotal += gerak;

        printf("STEP %d\n", step++);
        printf("Head di track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
    }

    // Ke ujung disk (199)
    if (head != disk_size - 1)
    {
        int gerak = disk_size - 1 - head;
        geraktotal += gerak;
        head = disk_size - 1;

        printf("STEP %d\n", step++);
        printf("Head di track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
    }

    // Lompat ke awal (track 0)
    int gerak = disk_size - 1;
    geraktotal += gerak;
    head = 0;

    printf("STEP %d\n", step++);
    printf("Head di track = %d\n", head);
    printf("Pergerakan = %d\n\n", gerak);

    // Lanjut melayani request yang di bawah
    for (int j = 0; j < i; j++)
    {
        headPrev = head;
        head = all[j];
        gerak = abs(head - headPrev);
        geraktotal += gerak;

        printf("STEP %d\n", step++);
        printf("Head di track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
    }

    printf("Total pergerakan head = %d\n", geraktotal);
}

// Fungsi C-Scan turun
void cscan_turun(int requests[], int n, int head, int disk_size)
{
    int all[n];
    int step = 1;
    int geraktotal = 0;
    int headPrev;

    for (int i = 0; i < n; i++)
        all[i] = requests[i];

    sort(all, n);

    int i;
    for (i = 0; i < n; i++)
    {
        if (all[i] >= head)
            break;
    }

    printf("STEP %d\n", step++);
    printf("Head di track = %d\n", head);
    printf("Pergerakan = 0\n\n");

    // Turun ke bawah
    for (int j = i - 1; j >= 0; j--)
    {
        headPrev = head;
        head = all[j];
        int gerak = abs(head - headPrev);
        geraktotal += gerak;

        printf("STEP %d\n", step++);
        printf("Head di track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
    }

    // Ke track 0 jika belum
    if (head != 0)
    {
        int gerak = head;
        geraktotal += gerak;
        head = 0;

        printf("STEP %d\n", step++);
        printf("Head di track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
    }

    // Lompat ke ujung disk (199)
    int gerak = disk_size - 1;
    geraktotal += gerak;
    head = disk_size - 1;

    printf("STEP %d\n", step++);
    printf("Head di track = %d\n", head);
    printf("Pergerakan = %d\n\n", gerak);

    // Lanjut melayani yang di atas
    for (int j = n - 1; j >= i; j--)
    {
        headPrev = head;
        head = all[j];
        gerak = abs(head - headPrev);
        geraktotal += gerak;

        printf("STEP %d\n", step++);
        printf("Head di track = %d\n", head);
        printf("Pergerakan = %d\n\n", gerak);
    }

    printf("Total pergerakan head = %d\n", geraktotal);
}

int main()
{
    int n, head, disk_size = 200, opsi;

    printf("Masukkan jumlah request: ");
    scanf("%d", &n);

    int requests[n];

    printf("Masukkan posisi head awal: ");
    scanf("%d", &head);

    printf("Masukkan request (dipisah spasi): ");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &requests[i]);
    }

    do
    {
        printf("Pilih algoritma serta arah awalnya:\n1. C-SCAN (Arah awal = naik)\n2. C-SCAN (Arah awal = turun)\n3. C-LOOK (Arah awal = naik)\n4. C-LOOK (Arah awal = turun)\nOpsi: ");
        scanf("%d", &opsi);

        if (opsi == 1)
        {
            printf("\n[Algoritma: C-SCAN (Naik)]\n\n");
            cscan_naik(requests, n, head, disk_size);
        }
        else if (opsi == 2)
        {
            printf("\n[Algoritma: C-SCAN (Turun)]\n\n");
            cscan_turun(requests, n, head, disk_size);
        }
        else if (opsi == 3)
        {
            printf("\n[Algoritma : C-LOOK (Naik)]\n\n");
            clook_naik(requests, n, head, disk_size);
        }
        else if (opsi == 4)
        {
            printf("\n[Algoritma : C-LOOK (Turun)]\n\n");
            clook_turun(requests, n, head, disk_size);
        }
        else
        {
            printf("Opsi tidak valid!\n");
        }
    } while (opsi < 1 && opsi > 4);

    return 0;
}

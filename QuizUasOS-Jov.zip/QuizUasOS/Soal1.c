#include <stdio.h>
#include <stdbool.h>

#define MAX 100

// Fungsi untuk mengecek apakah halaman sudah ada di frame
bool isInFrame(int frame[], int frameSize, int page) {
    for (int i = 0; i < frameSize; i++) {
        if (frame[i] == page)
            return true;
    }
    return false;
}

// Fungsi untuk algoritma Optimal Page Replacement
int optimal(int pages[], int n, int frameSize) {
    int frame[frameSize];
    int pageFaults = 0;

    // Inisialisasi frame kosong
    for (int i = 0; i < frameSize; i++)
        frame[i] = -1;

    for (int i = 0; i < n; i++) {
        // Jika halaman tidak ada di frame, maka terjadi page fault
        if (!isInFrame(frame, frameSize, pages[i])) {
            int indexToReplace = -1, farthest = i + 1;

            // Cek apakah ada frame kosong
            for (int j = 0; j < frameSize; j++) {
                if (frame[j] == -1) {
                    indexToReplace = j;
                    break;
                }
            }

            // Jika tidak ada frame kosong, cari yang paling lama digunakan di masa depan
            if (indexToReplace == -1) {
                int maxDist = -1;
                for (int j = 0; j < frameSize; j++) {
                    int k;
                    for (k = i + 1; k < n; k++) {
                        if (frame[j] == pages[k])
                            break;
                    }
                    if (k == n) {
                        indexToReplace = j;
                        break;
                    }
                    if (k - i > maxDist) {
                        maxDist = k - i;
                        indexToReplace = j;
                    }
                }
            }

            frame[indexToReplace] = pages[i];
            pageFaults++;
        }
    }

    return pageFaults;
}

// Fungsi untuk mencari indeks halaman LRU
int findLRU(int time[], int frameSize) {
    int min = time[0], pos = 0;
    for (int i = 1; i < frameSize; i++) {
        if (time[i] < min) {
            min = time[i];
            pos = i;
        }
    }
    return pos;
}

// Fungsi untuk algoritma Least Recently Used (LRU)
int lru(int pages[], int n, int frameSize) {
    int frame[frameSize];
    int time[frameSize];  // Untuk mencatat waktu akses terakhir
    int pageFaults = 0, counter = 0;

    // Inisialisasi frame kosong
    for (int i = 0; i < frameSize; i++)
        frame[i] = -1;

    for (int i = 0; i < n; i++) {
        bool found = false;

        // Cek apakah halaman sudah ada di frame
        for (int j = 0; j < frameSize; j++) {
            if (frame[j] == pages[i]) {
                counter++;
                time[j] = counter;
                found = true;
                break;
            }
        }

        // Jika tidak ditemukan, lakukan page replacement
        if (!found) {
            int pos = -1;

            // Cari frame kosong
            for (int j = 0; j < frameSize; j++) {
                if (frame[j] == -1) {
                    pos = j;
                    break;
                }
            }

            // Jika tidak ada frame kosong, ganti dengan halaman yang paling lama tidak digunakan
            if (pos == -1)
                pos = findLRU(time, frameSize);

            frame[pos] = pages[i];
            counter++;
            time[pos] = counter;
            pageFaults++;
        }
    }

    return pageFaults;
}

int main() {
    int frameSize = 4; //Jumlah frame memori
    int pages[] = {4, 1, 0, 2, 1, 0, 3, 4, 1, 0, 2, 3}; //Referensi halamannya
    int n = sizeof(pages) / sizeof(pages[0]);

    // Hitung jumlah page fault untuk masing-masing algoritma
    int optimalFaults = optimal(pages, n, frameSize);
    int lruFaults = lru(pages, n, frameSize);

    // Tampilkan hasil
    printf("Optimal Page Faults: %d\n", optimalFaults);
    printf("LRU Page Faults    : %d\n", lruFaults);

    return 0;
}
